This is a python wrapper for the bliss tool.


Bliss
-----

bliss is an open-source tool for computing
canonical labelings and automorphism groups of graphs.

This is a github copy of the original software,
for more information about bliss, please see the bliss homepage at
https://users.aalto.fi/tjunttil/bliss